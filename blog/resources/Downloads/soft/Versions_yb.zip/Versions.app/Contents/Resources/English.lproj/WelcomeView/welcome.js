$(document).ready(function() {
	// Convert buttons to jQuery-UI Buttons so that we get proper active state mouse-tracking
	$( "button" ).button();
});
